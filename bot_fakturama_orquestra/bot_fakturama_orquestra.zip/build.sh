#!/bin/bash

zip -r "bot_fakturama_orquestra.zip" * -x "bot_fakturama_orquestra.zip"