#!/bin/bash

zip -r "bot_user_name.zip" * -x "bot_user_name.zip"